# material-apoyo-udea
Este repositorio contiene recursos de información para conversatorio de datos en la universidad de Antioquia.
